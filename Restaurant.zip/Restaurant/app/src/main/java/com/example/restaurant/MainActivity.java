package com.example.restaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, RatingBar.OnRatingBarChangeListener {
    CheckBox palak, chola, daal, rajma, aaloo, chicken, mutton, omelette, fish, egg, tikka, manchuri, noodles, fries, corn, chocolate, vanilla, pineapple, cherry, dbc, apple, mango, melon, orange, banana;
    TextView textView;
    RadioGroup radioGroup;
    RadioButton radioButton;
    RatingBar ratingBar;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        palak = findViewById(R.id.cbpaneer);
        chola = findViewById(R.id.cbchola);
        daal = findViewById(R.id.cbmakhani);
        rajma = findViewById(R.id.cbrajma);
        aaloo = findViewById(R.id.cbparatha);
        chicken = findViewById(R.id.cbchicken);
        mutton = findViewById(R.id.cbmutton);
        omelette = findViewById(R.id.cbomelette);
        fish = findViewById(R.id.cbfish);
        egg = findViewById(R.id.cbegg);
        tikka = findViewById(R.id.cbtikka);
        manchuri = findViewById(R.id.cbmanchuri);
        noodles = findViewById(R.id.cbnoodles);
        fries = findViewById(R.id.cbfries);
        corn = findViewById(R.id.cbcorn);
        chocolate = findViewById(R.id.cbchoco);
        vanilla = findViewById(R.id.cbvanilla);
        pineapple = findViewById(R.id.cbpineapple);
        cherry = findViewById(R.id.cbcherry);
        dbc = findViewById(R.id.cbdbc);
        apple = findViewById(R.id.cbapple);
        mango = findViewById(R.id.cbmango);
        melon = findViewById(R.id.cbmelon);
        orange = findViewById(R.id.cborange);
        banana = findViewById(R.id.cbbanana);

        textView = findViewById(R.id.tvdisplay);
        textView2 = findViewById(R.id.tv2);
        ratingBar = findViewById(R.id.ratingbar);


        radioGroup.setOnCheckedChangeListener(this);
        ratingBar.setOnRatingBarChangeListener(this);

    }

    public void button(View view) {
        String food = "";
        if (palak.isChecked()) {
            food = palak.getText().toString();
            textView.setText(food);
        }
        if (chola.isChecked()) {
            food = food + chola.getText();
            textView.setText(food);
        }
        if (daal.isChecked()) {
            food = food + daal.getText();
            textView.setText(food);
        }
        if (rajma.isChecked()) {
            food = food + rajma.getText();
            textView.setText(food);
        }
        if (chicken.isChecked()) {
            food = food + chicken.getText();
            textView.setText(food);
        }
        if (mutton.isChecked()) {
            food = food + mutton.getText();
            textView.setText(food);
        }
        if (omelette.isChecked()) {
            food = food + omelette.getText();
            textView.setText(food);
        }
        if (tikka.isChecked()) {
            food = food + tikka.getText();
            textView.setText(food);
        }
        if (manchuri.isChecked()) {
            food = food + manchuri.getText();
            textView.setText(food);
        }
        if (noodles.isChecked()) {
            food = food + noodles.getText();
            textView.setText(food);
        }
        if (fries.isChecked()) {
            food = food + fries.getText();
            textView.setText(food);
        }
        if (corn.isChecked()) {
            food = food + corn.getText();
            textView.setText(food);
        }
        if (chocolate.isChecked()) {
            food = food + chocolate.getText();
            textView.setText(food);
        }
        if (vanilla.isChecked()) {
            food = food + vanilla.getText();
        }
        if (pineapple.isChecked()) {
            food = food + pineapple.getText();
            textView.setText(food);
        }
        if (cherry.isChecked()) {
            food = food + cherry.getText();
            textView.setText(food);
        }
        if (dbc.isChecked()) {
            food = food + dbc.getText();
            textView.setText(food);
        }
        if (apple.isChecked()) {
            food = food + apple.getText();
            textView.setText(food);
        }
        if (mango.isChecked()) {
            food = food + mango.getText();
            textView.setText(food);
        }
        if (melon.isChecked()) {
            food = food + melon.getText();
            textView.setText(food);
        }
        if (orange.isChecked()) {
            food = food + orange.getText();
            textView.setText(food);
        }
        if (banana.isChecked()) {
            food = food + banana.getText();
            textView.setText(food);
        }

    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        radioButton = findViewById(i);
        String money = radioButton.getText().toString();
        radioButton.setText(money);

    }

    @Override
    public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
        v = ratingBar.getRating();
        textView2.setText(v+"");

    }
}
